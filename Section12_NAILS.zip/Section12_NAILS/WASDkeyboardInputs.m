clc,clearvars, clear
f = figure;
global Keypressed
Keypressed = 6;

set(f,'WindowKeyPressFcn',@keyPressCallback);


 for i=1:1000
     %This is checking if the keys where pressed according to WASD and
     %outputs either true (1) or false (0)
     Winput = strcmp(Keypressed,'w');
     Ainput = strcmp(Keypressed,'a');
     Sinput = strcmp(Keypressed,'s');
     Dinput = strcmp(Keypressed,'d');
     i = i+1;
     pause(.01)


     %This checks which input is true and then out puts a command if
     %that output is true
    if Winput == 1
     fprintf('move up')

    elseif Ainput == 1
     fprintf('move left')

    elseif Sinput == 1
     fprintf('move down')
          
    elseif Dinput == 1
     fprintf('move right')
    end
 end

